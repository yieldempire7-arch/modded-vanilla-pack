#version 400 compatibility
#define DIMENSION_GENERIC

#include "/program/shadow.fsh"
